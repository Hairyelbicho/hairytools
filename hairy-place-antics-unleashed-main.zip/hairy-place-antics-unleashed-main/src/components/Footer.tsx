import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Heart, Mail, Phone, MapPin } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-background border-t">
      <div className="container px-4 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-gradient-primary rounded-full flex items-center justify-center shadow-glow">
                <span className="text-white font-bold text-xl">H</span>
              </div>
              <span className="text-2xl font-bold text-gradient">HairyPlace</span>
            </div>
            <p className="text-muted-foreground">
              La plataforma más avanzada para mascotas, combinando e-commerce, 
              blockchain y NFTs en un solo lugar.
            </p>
            <div className="flex space-x-4">
              <Button variant="ghost" size="icon">
                <span className="text-xl">🐕</span>
              </Button>
              <Button variant="ghost" size="icon">
                <span className="text-xl">🐱</span>
              </Button>
              <Button variant="ghost" size="icon">
                <span className="text-xl">🦜</span>
              </Button>
            </div>
          </div>

          {/* Shop */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Tienda</h3>
            <ul className="space-y-2 text-muted-foreground">
              <li><a href="#" className="hover:text-primary transition-colors">Comida Premium</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Juguetes</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Accesorios</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Cuidado & Salud</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Ofertas Especiales</a></li>
            </ul>
          </div>

          {/* Blockchain */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Blockchain</h3>
            <ul className="space-y-2 text-muted-foreground">
              <li><a href="#" className="hover:text-primary transition-colors">HairyWallet</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">NFT Marketplace</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Exchange</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Suscripciones</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">IA de Inversiones</a></li>
            </ul>
          </div>

          {/* Newsletter */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Newsletter</h3>
            <p className="text-muted-foreground">
              Recibe las últimas noticias sobre productos y ofertas exclusivas.
            </p>
            <div className="space-y-2">
              <Input 
                placeholder="Tu email"
                className="bg-background/50"
              />
              <Button className="w-full bg-gradient-primary hover:opacity-90 shadow-glow">
                <Mail className="h-4 w-4 mr-2" />
                Suscribirse
              </Button>
            </div>
          </div>
        </div>

        <Separator className="my-8" />

        {/* Contact Info */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-primary/10 rounded-lg">
              <Mail className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="font-medium">Email</p>
              <p className="text-muted-foreground">hello@hairyelbicho.com</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-secondary/10 rounded-lg">
              <Phone className="h-5 w-5 text-secondary" />
            </div>
            <div>
              <p className="font-medium">Soporte</p>
              <p className="text-muted-foreground">24/7 Chat en vivo</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-accent/10 rounded-lg">
              <MapPin className="h-5 w-5 text-accent" />
            </div>
            <div>
              <p className="font-medium">Global</p>
              <p className="text-muted-foreground">Envíos mundiales</p>
            </div>
          </div>
        </div>

        <Separator className="my-8" />

        {/* Bottom */}
        <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <div className="flex items-center space-x-2 text-muted-foreground">
            <span>© 2024 HairyPlace. Hecho con</span>
            <Heart className="h-4 w-4 text-red-500 fill-current" />
            <span>para las mascotas.</span>
          </div>
          
          <div className="flex space-x-6 text-sm text-muted-foreground">
            <a href="#" className="hover:text-primary transition-colors">Términos</a>
            <a href="#" className="hover:text-primary transition-colors">Privacidad</a>
            <a href="#" className="hover:text-primary transition-colors">Cookies</a>
          </div>
        </div>
      </div>
    </footer>
  );
}