import { Card, CardContent } from "@/components/ui/card";

const categories = [
  {
    id: 1,
    name: "Comida Premium",
    icon: "🥘",
    color: "bg-gradient-primary",
    products: "120+ productos"
  },
  {
    id: 2,
    name: "Juguetes",
    icon: "🎾",
    color: "bg-gradient-secondary", 
    products: "85+ productos"
  },
  {
    id: 3,
    name: "Accesorios",
    icon: "🎀",
    color: "bg-gradient-accent",
    products: "200+ productos"
  },
  {
    id: 4,
    name: "Cuidado & Salud",
    icon: "💊",
    color: "bg-gradient-primary",
    products: "150+ productos"
  },
  {
    id: 5,
    name: "Camas & Comfort",
    icon: "🛏️",
    color: "bg-gradient-secondary",
    products: "75+ productos"
  },
  {
    id: 6,
    name: "NFTs Exclusivos",
    icon: "🎨",
    color: "bg-gradient-rainbow",
    products: "500+ NFTs"
  }
];

export function ProductCategories() {
  return (
    <section className="py-16 lg:py-24">
      <div className="container px-4 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">
            Categorías <span className="text-gradient">Populares</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Descubre productos únicos para tu mascota y explora nuestro marketplace de NFTs
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories.map((category) => (
            <Card 
              key={category.id}
              className="group cursor-pointer hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border-0 shadow-md"
            >
              <CardContent className="p-6">
                <div className="text-center space-y-4">
                  <div className={`w-16 h-16 ${category.color} rounded-2xl mx-auto flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-glow`}>
                    <span className="text-3xl">{category.icon}</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold mb-1">
                      {category.name}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      {category.products}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}