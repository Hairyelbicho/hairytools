import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Wallet, TrendingUp, Shield, Zap, PiggyBank, Palette } from "lucide-react";

const features = [
  {
    icon: Wallet,
    title: "HairyWallet",
    description: "Conecta tu wallet descentralizada para pagos seguros",
    color: "bg-gradient-primary",
    status: "Próximamente"
  },
  {
    icon: TrendingUp,
    title: "Exchange Crypto",
    description: "Intercambia criptomonedas con IA experta en inversiones",
    color: "bg-gradient-secondary",
    status: "Beta"
  },
  {
    icon: Palette,
    title: "NFT Marketplace",
    description: "Compra, vende y crea NFTs únicos de mascotas",
    color: "bg-gradient-accent",
    status: "Activo"
  },
  {
    icon: Shield,
    title: "IA de Seguridad",
    description: "Protección avanzada para todas tus transacciones",
    color: "bg-gradient-primary",
    status: "Activo"
  },
  {
    icon: Zap,
    title: "Pagos Instantáneos",
    description: "Transacciones rápidas con tarifas mínimas",
    color: "bg-gradient-secondary",
    status: "Activo"
  },
  {
    icon: PiggyBank,
    title: "Suscripciones Premium",
    description: "Acceso exclusivo a productos y servicios",
    color: "bg-gradient-accent",
    status: "Disponible"
  }
];

export function CryptoFeatures() {
  return (
    <section className="py-16 lg:py-24">
      <div className="container px-4 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">
            Tecnología <span className="text-gradient">Blockchain</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Una plataforma completa que combina e-commerce, DeFi y NFTs para crear 
            la mejor experiencia para ti y tu mascota
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <Card 
              key={index}
              className="group cursor-pointer hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border-0 shadow-md"
            >
              <CardContent className="p-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className={`p-3 ${feature.color} rounded-xl shadow-glow`}>
                      <feature.icon className="h-6 w-6 text-white" />
                    </div>
                    <Badge 
                      variant="secondary" 
                      className="text-xs"
                    >
                      {feature.status}
                    </Badge>
                  </div>
                  
                  <div>
                    <h3 className="text-xl font-semibold mb-2 group-hover:text-primary transition-colors">
                      {feature.title}
                    </h3>
                    <p className="text-muted-foreground leading-relaxed">
                      {feature.description}
                    </p>
                  </div>
                  
                  <Button 
                    variant="ghost" 
                    className="w-full hover:bg-primary/5 hover:text-primary"
                  >
                    Saber Más
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Call to Action */}
        <div className="mt-16 text-center">
          <div className="bg-gradient-rainbow p-8 rounded-3xl shadow-xl">
            <h3 className="text-2xl lg:text-3xl font-bold text-white mb-4">
              ¿Listo para el Futuro de las Mascotas?
            </h3>
            <p className="text-white/90 mb-6 max-w-2xl mx-auto">
              Únete a la revolución blockchain para mascotas. Conecta tu wallet, 
              explora NFTs únicos y accede a servicios premium.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                className="bg-white text-primary hover:bg-white/90 shadow-lg"
              >
                Conectar Wallet
              </Button>
              <Button 
                variant="outline" 
                size="lg"
                className="border-white text-white hover:bg-white/10"
              >
                Explorar NFTs
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}