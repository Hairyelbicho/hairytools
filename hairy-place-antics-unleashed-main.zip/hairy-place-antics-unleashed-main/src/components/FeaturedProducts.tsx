import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Star, ShoppingCart, Heart } from "lucide-react";

const products = [
  {
    id: 1,
    name: "Hairy Premium Nutrition",
    image: "🐕",
    price: "49.99",
    originalPrice: "59.99",
    rating: 4.8,
    reviews: 124,
    badge: "Bestseller",
    weight: "18kg"
  },
  {
    id: 2,
    name: "Hairy Cat Premium",
    image: "🐱",
    price: "39.99",
    originalPrice: "45.99",
    rating: 4.9,
    reviews: 89,
    badge: "Premium",
    weight: "10kg"
  },
  {
    id: 3,
    name: "Juguete Interactivo",
    image: "🎾",
    price: "24.99",
    rating: 4.7,
    reviews: 56,
    badge: "Nuevo"
  },
  {
    id: 4,
    name: "Cama Luxury",
    image: "🛏️",
    price: "89.99",
    originalPrice: "109.99",
    rating: 4.9,
    reviews: 34,
    badge: "Oferta"
  }
];

export function FeaturedProducts() {
  return (
    <section className="py-16 lg:py-24 bg-muted/20">
      <div className="container px-4 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">
            Productos <span className="text-gradient">Destacados</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Los productos favoritos de nuestros clientes peludos
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product) => (
            <Card 
              key={product.id}
              className="group cursor-pointer hover:shadow-xl transition-all duration-300 hover:-translate-y-2 border-0 shadow-md overflow-hidden"
            >
              <CardContent className="p-0">
                {/* Product Image */}
                <div className="relative bg-gradient-primary/10 h-48 flex items-center justify-center">
                  <span className="text-6xl">{product.image}</span>
                  {product.badge && (
                    <Badge 
                      className="absolute top-3 left-3 bg-gradient-secondary text-secondary-foreground"
                    >
                      {product.badge}
                    </Badge>
                  )}
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute top-3 right-3 bg-white/80 hover:bg-white opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <Heart className="h-4 w-4" />
                  </Button>
                </div>

                {/* Product Info */}
                <div className="p-4 space-y-3">
                  <div>
                    <h3 className="font-semibold text-lg group-hover:text-primary transition-colors">
                      {product.name}
                    </h3>
                    {product.weight && (
                      <p className="text-sm text-muted-foreground">{product.weight}</p>
                    )}
                  </div>

                  {/* Rating */}
                  <div className="flex items-center space-x-2">
                    <div className="flex items-center">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      <span className="text-sm font-medium ml-1">{product.rating}</span>
                    </div>
                    <span className="text-sm text-muted-foreground">
                      ({product.reviews} reseñas)
                    </span>
                  </div>

                  {/* Price */}
                  <div className="flex items-center space-x-2">
                    <span className="text-2xl font-bold text-primary">
                      ${product.price}
                    </span>
                    {product.originalPrice && (
                      <span className="text-sm text-muted-foreground line-through">
                        ${product.originalPrice}
                      </span>
                    )}
                  </div>

                  {/* Add to Cart Button */}
                  <Button 
                    className="w-full bg-gradient-primary hover:opacity-90 shadow-glow"
                    size="sm"
                  >
                    <ShoppingCart className="h-4 w-4 mr-2" />
                    Agregar al Carrito
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button 
            variant="outline" 
            size="lg"
            className="border-primary/20 hover:bg-primary/5"
          >
            Ver Todos los Productos
          </Button>
        </div>
      </div>
    </section>
  );
}