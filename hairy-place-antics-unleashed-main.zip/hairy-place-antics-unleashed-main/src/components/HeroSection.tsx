import { Button } from "@/components/ui/button";
import { ArrowRight, Shield, Zap, Globe } from "lucide-react";

export function HeroSection() {
  return (
    <section className="relative overflow-hidden">
      {/* Background Gradient */}
      <div className="absolute inset-0 bg-gradient-rainbow opacity-10"></div>
      
      <div className="container px-4 lg:px-8 py-20 lg:py-32">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-4xl lg:text-6xl font-bold leading-tight">
                La Tienda del Futuro para
                <span className="text-gradient"> Mascotas</span>
              </h1>
              <p className="text-xl text-muted-foreground leading-relaxed">
                Compra, vende y crea NFTs de mascotas. Conecta tu HairyWallet, 
                intercambia criptomonedas y accede a productos premium para tu 
                mejor amigo.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                size="lg" 
                className="bg-gradient-primary hover:opacity-90 shadow-glow text-lg px-8"
              >
                Explorar Tienda
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button 
                variant="outline" 
                size="lg"
                className="text-lg px-8 border-primary/20 hover:bg-primary/5"
              >
                Conectar Wallet
              </Button>
            </div>

            {/* Features */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-8">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <Shield className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold">Seguro</h3>
                  <p className="text-sm text-muted-foreground">IA de seguridad</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-secondary/10 rounded-lg">
                  <Zap className="h-6 w-6 text-secondary" />
                </div>
                <div>
                  <h3 className="font-semibold">Rápido</h3>
                  <p className="text-sm text-muted-foreground">Pagos instantáneos</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-accent/10 rounded-lg">
                  <Globe className="h-6 w-6 text-accent" />
                </div>
                <div>
                  <h3 className="font-semibold">Global</h3>
                  <p className="text-sm text-muted-foreground">Exchange mundial</p>
                </div>
              </div>
            </div>
          </div>

          {/* Hero Image Placeholder */}
          <div className="relative">
            <div className="aspect-square bg-gradient-primary/20 rounded-3xl shadow-glow p-8 flex items-center justify-center">
              <div className="text-center space-y-4">
                <div className="w-32 h-32 bg-gradient-secondary rounded-full mx-auto flex items-center justify-center">
                  <span className="text-4xl">🐕</span>
                </div>
                <div className="space-y-2">
                  <div className="w-24 h-3 bg-primary/30 rounded mx-auto"></div>
                  <div className="w-16 h-3 bg-secondary/30 rounded mx-auto"></div>
                </div>
              </div>
            </div>
            
            {/* Floating Elements */}
            <div className="absolute -top-4 -right-4 w-16 h-16 bg-gradient-accent rounded-2xl shadow-pink-glow flex items-center justify-center animate-pulse">
              <span className="text-2xl">🎾</span>
            </div>
            <div className="absolute -bottom-4 -left-4 w-20 h-20 bg-gradient-secondary rounded-2xl shadow-glow flex items-center justify-center animate-pulse">
              <span className="text-2xl">🦴</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}